package Finalproject;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Holidays {
	
	//driver initiate
		WebDriver driver;
		public Holidays(WebDriver driver) {
			this.driver=driver;
		}
		List<String>packs=new ArrayList<>();
		
		
		
		//Entries entered in List of packages
		public List<String> holidayslist(){
	
         List<WebElement>offer=driver.findElements(By.className("eventListTrackable"));
         
         System.out.println("Size of offer is:"+offer.size());
         for(int i=0;i<offer.size();i++) {
       		  WebElement o=offer.get(i);
       		  o.click();
         }
  
         ArrayList<String> handlesList = new ArrayList<>(driver.getWindowHandles());
         
         for(int i=2;i<handlesList.size();i++) {
	          	 String last = handlesList.get(i);
	                driver.switchTo().window(last);	    
	               if(driver.findElement(By.tagName("html")).getAttribute("ng-app")!=null) {
	              	  WebElement e=driver.findElement(By.className("cost"));
	              	  String a=e.getText().replace("\n", " ");
	              	  String st=driver.findElement(By.className("ng-binding")).getText();
	              	 packs.add(st+" "+a);
	                }
	                else if (!driver.findElements(By.id("booking_engine_modues")).isEmpty()) {
	                    packs.add(driver.getTitle());
	                }
	                else {
	                	continue;
	                }
	            }
         return packs;
		}
		
		//Display all the entries in Packages List
		public void display() {
			 System.out.println();
	            System.out.println("List of Packages are");
	            for(int i=0;i<packs.size();i++) {
	            System.out.println(packs.get(i));
	            }
	            System.out.println();
		}
		
		
		
}
