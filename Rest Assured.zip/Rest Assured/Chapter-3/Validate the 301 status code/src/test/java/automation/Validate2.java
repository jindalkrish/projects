package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;

public class Validate2 {

	@DisplayName("Validate status code 301")
	@Test
	void validate() {
	    RestAssured.given()
	    			.relaxedHTTPSValidation() 
	    			 .redirects().follow(false)
	                .when()
	                .get("https://the-internet.herokuapp.com/status_codes/301")
	                .then()
	                .statusCode(301);
	}
}