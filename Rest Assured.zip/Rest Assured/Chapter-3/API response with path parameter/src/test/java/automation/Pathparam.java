package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Pathparam {
	@DisplayName("API response with path parameter")
	@Test
	void APIresponse() {
		Response response=
	    RestAssured.given()
	    			.relaxedHTTPSValidation() 
	    			.pathParam("id",5)
	                .when()
	                .get("https://jsonplaceholder.typicode.com/posts/{id}");
		response.prettyPrint();
	}
}
