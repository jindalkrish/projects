package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Queryparam {
	@DisplayName("API response with double query parameter")
	@Test
	void APIresponse() {
		Response response=
	    RestAssured.given()
	    			.relaxedHTTPSValidation() 
	    			.queryParam("page",2)
	    			.queryParam("id", 5)
	                .when()
	                .get("https://reqres.in/api/users");
		response.prettyPrint();
	}
}
