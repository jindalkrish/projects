package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class response2 {
	@DisplayName("API response in XML")
	@Test
	void APIresponse() {
	    			
	    			Response response = RestAssured
	    					.given()
	    					.relaxedHTTPSValidation() 
			                .header("Accept", "application/xml") 
			                .when()
			                .get("https://restful-booker.herokuapp.com/booking/119");

	        System.out.println(response.asString());
		
	}
}
