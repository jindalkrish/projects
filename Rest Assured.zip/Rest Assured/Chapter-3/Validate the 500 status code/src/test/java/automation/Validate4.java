package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;

public class Validate4 {
	@DisplayName("Validate status code 500")
	@Test
	void validate() {
	    RestAssured.given()
	    			.relaxedHTTPSValidation() 
	                .when()
	                .get("https://the-internet.herokuapp.com/status_codes/500")
	                .then()
	                .statusCode(500);
	}
}
