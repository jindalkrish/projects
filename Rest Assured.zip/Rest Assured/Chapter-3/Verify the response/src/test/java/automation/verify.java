package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;

public class verify {
	@DisplayName("Verify Status Code")
	@Test
	void validate() {
	    RestAssured.given()
	    			.relaxedHTTPSValidation() 
	    			.auth().preemptive().basic("postman", "password")
	                .when()
	                .get("https://postman-echo.com/basic-auth")
	                .then()
	                .statusCode(200);
	}
}
