package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Queryparam {
	@DisplayName("API response with single query parameter")
	@Test
	void APIresponse() {
		Response response=
	    RestAssured.given()
	    			.relaxedHTTPSValidation() 
	    			.queryParam("page",2)
	                .when()
	                .get("https://reqres.in/api/users");
		response.prettyPrint();
	}
}
