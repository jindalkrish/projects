package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class baseURI {
	@DisplayName("API response with base URI")
	@Test
	void APIresponse() {
		RestAssured.baseURI="https://jsonplaceholder.typicode.com/posts";
		Response response=
	    RestAssured.given()
	    			.relaxedHTTPSValidation() 
	    			.pathParam("id",5)
	                .when()
	                .get("/{id}");
		response.prettyPrint();
	}
}
