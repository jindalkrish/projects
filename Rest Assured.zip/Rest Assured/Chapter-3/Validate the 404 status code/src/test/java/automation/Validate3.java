package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;

public class Validate3 {
	@DisplayName("Validate status code 404")
	@Test
	void validate() {
	    RestAssured.given()
	    			.relaxedHTTPSValidation() 
	                .when()
	                .get("https://the-internet.herokuapp.com/status_codes/404")
	                .then()
	                .statusCode(404);
	}
}
