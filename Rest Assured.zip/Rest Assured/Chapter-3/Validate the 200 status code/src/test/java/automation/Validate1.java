package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;

public class Validate1 {
	
	
	@DisplayName("Validate status code 200")
	@Test
	void validate() {
	    RestAssured.given()
	    			.relaxedHTTPSValidation() 
	                .when()
	                .get("https://the-internet.herokuapp.com/status_codes/200")
	                .then()
	                .statusCode(200);
	}
}