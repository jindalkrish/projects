package automation;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.ResponseSpecification;

public class Population {
	 @DisplayName("United States population details for the year 2019")
	    @Test
	    public void getPopulationDetails2019() {
	        // ✅ Build Response Specification
	        ResponseSpecification responseSpec = new ResponseSpecBuilder()
	            .expectStatusCode(200)
	            .expectContentType("application/json")
	            .build();

	        // 🌐 Send GET request
	        Response response = RestAssured
	            .given()
	                .baseUri("https://datausa.io")
	                .basePath("/api/data")
	                .queryParam("drilldowns", "Nation")
	                .queryParam("measures", "Population")
	                .queryParam("Year", "2019")
	            .when()
	                .get()
	            .then()
	                .spec(responseSpec)
	                .extract()
	                .response();

	        // 🧠 Parse and print response
	        JSONObject json = new JSONObject(response.getBody().asString());
	        JSONArray dataArray = json.getJSONArray("data");
	        JSONObject data = dataArray.getJSONObject(0);

	        System.out.println("ID Nation: " + data.getString("ID Nation"));
	        System.out.println("Nation: " + data.getString("Nation"));
	        System.out.println("ID Year: " + data.getInt("ID Year"));
	        System.out.println("Population: " + data.getInt("Population"));
	        System.out.println("Slug Nation: " + data.getString("Slug Nation"));

	        JSONObject source = json.getJSONArray("source").getJSONObject(0).getJSONObject("annotations");
	        System.out.println("Source Name: " + source.getString("source_name"));
	        System.out.println("Source Description: " + source.getString("source_description"));
	    }
}
