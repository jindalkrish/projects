package automation;

import static org.testng.Assert.assertEquals;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.testng.annotations.BeforeClass;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Population {
	Response response;
	@DisplayName("United States population details for the year 2020 setup")
	@BeforeClass
	void Setup() {
		RestAssured.baseURI = "https://datausa.io";
        RestAssured.basePath = "/api/data";
		response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .queryParam("drilldowns", "Nation")
		         .queryParam("measures","Population")
		         .queryParam("Year","2020")
		         .when()
		         .contentType(ContentType.JSON)
		         .when()
		         .get();
		response.prettyPrint();
		 assertEquals(response.getStatusCode(),200);
	}
	
	@DisplayName("United States population details for the year 2020")
	@Test
	void population() {
		List<Map<String,Object>>dataList=response.jsonPath().getList("$");
		for (Map<String, Object> entry : dataList) {
            System.out.println("ID Nation: " + entry.get("ID Nation"));
            System.out.println("Nation: " + entry.get("Nation"));
            System.out.println("ID Year: " + entry.get("ID Year"));
            System.out.println("Population: " + entry.get("Population"));
            System.out.println("Slug Nation: " + entry.get("Slug Nation"));
            System.out.println("--------------------------------------------------");
        }

        Map<String, Object> source = response.jsonPath().getMap("source[0].annotations");
        System.out.println("Source Name: " + source.get("source_name"));
        System.out.println("Source Description: " + source.get("source_description"));
	}
}
