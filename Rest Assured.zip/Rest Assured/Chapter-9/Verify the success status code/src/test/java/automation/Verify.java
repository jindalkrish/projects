package automation;

import static org.testng.Assert.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Verify {
	@DisplayName("Verify the success status code and response body")
	@Test
	void validate() {
	   Response response= RestAssured.given()
	    			.relaxedHTTPSValidation() 
	    			.auth().preemptive().basic("postman", "password")
	                .when()
	                .get("https://postman-echo.com/basic-auth");
	   response.prettyPrint();
	   assertEquals(response.getStatusCode(),200);
	}
}
