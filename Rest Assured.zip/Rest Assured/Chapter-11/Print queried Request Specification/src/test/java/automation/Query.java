package automation;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Query {
	@DisplayName("United States population details for the year 2021 setup")
    @BeforeAll
    static void setupRequestSpec() {
        // Set base URI and base path correctly
        RestAssured.baseURI = "https://datausa.io";
        RestAssured.basePath = "/api/data";
    }
	@DisplayName("United States population details for the year 2021")
    @Test
    void getPopulationDetails2020() {
        Response response = RestAssured
            .given()
                .relaxedHTTPSValidation()
                .queryParam("drilldowns", "Nation")
                .queryParam("measures", "Population")
                .queryParam("Year", "2021")
            .when()
                .get();

        // Print formatted response
        response.prettyPrint();

        // Print request meta information
        System.out.println("Base URI: " + RestAssured.baseURI);
        System.out.println("Base Path: " + RestAssured.basePath);
        System.out.println("Status Code: " + response.getStatusCode());
        System.out.println("Response Headers: \n" + response.getHeaders());
    }
}
