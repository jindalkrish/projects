package automation;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.json.JSONArray;
import org.json.JSONObject;

public class Population {

    RequestSpecification requestSpec;

    @BeforeClass
    public void setupRequestSpec() {
        requestSpec = RestAssured
            .given()
            .baseUri("https://datausa.io")
            .basePath("/api/data")
            .queryParam("drilldowns", "Nation")
            .queryParam("measures", "Population")
            .queryParam("Year", "2020");
    }

    @Test
    public void fetchPopulationData() {
        // Step 5: Send GET request
        Response response = requestSpec.get();

        // Step 5: Verify status code
        int statusCode = response.getStatusCode();
        assert statusCode == 200 : "Expected status code 200 but got " + statusCode;

        // Step 6–11: Parse and print response
        JSONObject json = new JSONObject(response.getBody().asString());

        JSONArray dataArray = json.getJSONArray("data");
        JSONObject data = dataArray.getJSONObject(0);

        System.out.println("ID Nation: " + data.getString("ID Nation"));
        System.out.println("Nation: " + data.getString("Nation"));
        System.out.println("ID Year: " + data.getInt("ID Year"));
        System.out.println("Population: " + data.getInt("Population"));
        System.out.println("Slug Nation: " + data.getString("Slug Nation"));

        JSONArray sourceArray = json.getJSONArray("source");
        JSONObject source = sourceArray.getJSONObject(0);
        JSONObject annotations = source.getJSONObject("annotations");

        System.out.println("Source Name: " + annotations.getString("source_name"));
        System.out.println("Source Description: " + annotations.getString("source_description"));
    }
}
