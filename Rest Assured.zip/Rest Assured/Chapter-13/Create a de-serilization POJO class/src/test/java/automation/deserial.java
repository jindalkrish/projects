package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class deserial {
	@DisplayName("Create a deserilization POJO class")
	@Test
	void APIresponse() throws Exception {
		RestAssured.baseURI="https://restful-booker.herokuapp.com/booking/1139";
		
		Response response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .contentType(ContentType.JSON)
		         .get();
		response.prettyPrint();
		setup p=response.as(setup.class);
		System.out.println("First Name: " + p.firstname);
        System.out.println("Last Name: " +p.lastname);
        System.out.println("bookingdates: " + p.bookingdates);
        System.out.println("Additional Needs: " + p.additionalneeds);
        System.out.println("totalprice: " + p.totalprice);
        System.out.println("depositpaid: " + p.depositpaid);
    }
}
