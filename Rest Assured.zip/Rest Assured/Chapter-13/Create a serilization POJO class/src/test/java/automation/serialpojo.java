package automation;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class serialpojo {
	@DisplayName("Create a serilization POJO class")
	@Test
	void APIresponse() throws Exception {
		setup p=new setup();
		RestAssured.baseURI="https://restful-booker.herokuapp.com/booking";
		p.setFirstname("Jim");
		p.setLastname("Brown");
		p.setTotalprice(111);
		p.setDepositpaid(true);
		p.setAdditionalneeds("Breakfast");
		Map<String,String>mp=new HashMap<>();
		mp.put("checkin", "2018-01-01");
		mp.put("checkout", "2019-01-01");
		p.setBookingdates(mp);
		Response response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .contentType(ContentType.JSON)
		         .when()
		         .body(p)
		         .post();

		response.prettyPrint();
	}
}
