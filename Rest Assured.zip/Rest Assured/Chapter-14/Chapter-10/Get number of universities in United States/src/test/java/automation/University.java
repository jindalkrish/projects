package automation;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class University {
	@DisplayName("Number of universities in United States")
	@Test
	void APIresponse() {

		Response response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .queryParam("country", "United States")
		         .when()
		         .get("http://universities.hipolabs.com/search");
		response.prettyPrint();
		List<Map<String,Object>>mp=response.jsonPath().getList("$");
		System.out.println("Number of universities in United States are "+mp.size());
		
	}
}
