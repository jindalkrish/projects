package automation;

import java.io.FileWriter;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class University {
	@DisplayName("Number of universities in Canada")
	@Test
	void APIresponse() throws Exception {

		Response response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .queryParam("country", "Canada")
		         .when()
		         .get("http://universities.hipolabs.com/search");
		response.prettyPrint();
		List<Map<String,Object>>mp=response.jsonPath().getList("$");
		System.out.println("Number of universities in Canada are "+mp.size());
		
		try (FileWriter writer = new FileWriter("canada.txt")) {
            writer.write("Total universities in Canada: " + mp.size() + "\n\n");
            for (Map<String, Object> uni : mp) {
                writer.write("Name: " + uni.get("name") + "\n");
                writer.write("🌐 Website: " + ((List<?>) uni.get("web_pages")).get(0) + "\n");
                writer.write("📍 Country: " + uni.get("country") + "\n");
                writer.write("🔗 Domain: " + ((List<?>) uni.get("domains")).get(0) + "\n");
                writer.write("--------------------------------------------------\n");
            }
        }

        System.out.println("✅ Response log saved to canada.txt");
		
	}
}
