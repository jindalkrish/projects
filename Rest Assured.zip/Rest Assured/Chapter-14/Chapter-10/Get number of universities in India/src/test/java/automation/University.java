package automation;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;

public class University {
	@DisplayName("Number of universities in India")
	@Test
	void APIresponse() {

		Response response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .queryParam("country", "India")
		         .filter(new ResponseLoggingFilter()) 
		         .when()
		         .get("http://universities.hipolabs.com/search");
		response.prettyPrint();
		List<Map<String,Object>>mp=response.jsonPath().getList("$");
		System.out.println("Number of universities in India are "+mp.size());
		
	}
}
