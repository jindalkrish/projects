package automation;

import static org.testng.Assert.assertEquals;

import java.io.FileReader;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Request1 {
	@DisplayName("Verify the success status code 200")
	@Test
	void verify() throws Exception {
		RestAssured.baseURI="https://api.restful-api.dev/objects";
		JSONParser parser = new JSONParser();
        Object obj = parser.parse(new FileReader("samsung.json"));
        JSONObject jsonBody = (JSONObject) obj;
		Response response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .contentType(ContentType.JSON)
		         .when()
		         .body(jsonBody.toJSONString())
		         .post();
	   response.prettyPrint();
	   assertEquals(response.getStatusCode(),200);
	}
}
