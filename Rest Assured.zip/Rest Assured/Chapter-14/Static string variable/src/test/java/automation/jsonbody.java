package automation;

public class jsonbody {
	static String s="{\r\n"
			+ "    \"name\": \"Apple MacBook Pro 16\",\r\n"
			+ "    \"data\": {\r\n"
			+ "       \"year\": 2019,\r\n"
			+ "       \"price\": 1849.99,\r\n"
			+ "       \"CPU model\": \"Intel Core i9\",\r\n"
			+ "       \"Hard disk size\": \"1 TB\"\r\n"
			+ "    }\r\n"
			+ " }";
}
