package automation;

import static org.testng.Assert.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Request1 {
	@DisplayName("Verify the success status code 200")
	@Test
	void validate() {
		RestAssured.baseURI="https://api.restful-api.dev/objects";
		String s="{\r\n"
				+ "    \"name\": \"Apple MacBook Pro 16\",\r\n"
				+ "    \"data\": {\r\n"
				+ "       \"year\": 2019,\r\n"
				+ "       \"price\": 1849.99,\r\n"
				+ "       \"CPU model\": \"Intel Core i9\",\r\n"
				+ "       \"Hard disk size\": \"1 TB\"\r\n"
				+ "    }\r\n"
				+ " }";
		Response response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .contentType(ContentType.JSON)
		         .when()
		         .body(s)
		         .post();
	   response.prettyPrint();
	   assertEquals(response.getStatusCode(),200);
	}
}
