package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;

public class bitcoin {
	@DisplayName("Verify Bitcoin status code 200")
	@Test
	void validate() {
	    RestAssured.given()
	    			.relaxedHTTPSValidation() 
	                .when()
	                .get("https://api.coindesk.com/v1/bpi/currentprice.json")
	                .then()
	                .statusCode(200);
	    
	}
	
	@DisplayName("Verify Bitcoin status code 404")
	@Test
	void validate2() {
	    RestAssured.given()
	    			.relaxedHTTPSValidation() 
	                .when()
	                .get("https://api.coindesk.com/v1/bpi/currentprice.json")
	                .then()
	                .statusCode(404);
	}
}
