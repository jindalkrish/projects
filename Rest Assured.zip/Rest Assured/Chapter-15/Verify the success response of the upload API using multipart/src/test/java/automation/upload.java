package automation;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.net.URL;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class upload {
	@DisplayName("Verify the success status code 200")
	@Test
	void verify() throws Exception {
		 ClassLoader classLoader = getClass().getClassLoader();
	        URL resourceUrl = classLoader.getResource("fileupload");
		RestAssured.baseURI="https://the-internet.herokuapp.com/upload";
		File file=new File(resourceUrl.toURI());
		Response response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .multiPart("file", file)
		         .when()
		         .post();
	   response.prettyPrint();
	   assertEquals(response.getStatusCode(),200);
	}
}
