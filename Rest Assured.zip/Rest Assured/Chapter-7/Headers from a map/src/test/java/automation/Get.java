package automation;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Get {
	@DisplayName("Get the response of an API by setting headers from a map")
	@Test
	void APIresponse() {
		RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
		Map<String,String>mp=new HashMap<>();
		mp.put("Content-Type", "application/json");
		mp.put("Accept", "application/json");
		String s="{\"username\":\"admin\",\"password\":\"password123\"}";
		Response response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .headers(mp)
		         .when()
		         .body(s)
		         .post();
		response.prettyPrint();
		assertEquals(200,response.statusCode(),"statuscode mismatch");
		String t=response.jsonPath().getString("token");
		assertNotNull(t,"token is null");
	}
}
