package automation;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Redirect {
	@DisplayName("Limit the number of redirects")
	@Test
	void APIresponse() {
		Response response = RestAssured.given()
				.redirects().max(1)
				.relaxedHTTPSValidation() 
		         .when()
		         .get("https://simple-tool-rental-api.glitch.me/status");
		        
		response.prettyPrint();
		int redirectCount = response.getDetailedCookies().size();
		assertTrue(redirectCount == 0 || redirectCount == 1, "Redirect count should be 0 or 1");

		if (response.statusCode() == 410) {
		    System.out.println("Endpoint has been permanently removed.");
		} else {
		    assertEquals(response.statusCode(), 200, "Expected 200 OK");
		}

	}
}
