package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;

public class Valid {
	@DisplayName("Validating response using Custom Parsers")
	@Test
	void APIresponse() {
		RestAssured.baseURI="https://restful-booker.herokuapp.com/booking";
		RestAssured.registerParser("text/custom", Parser.TEXT);
		String s="{\r\n"
				+ "     \"firstname\": \"Jim\",\r\n"
				+ "     \"lastname\": \"Brown\",\r\n"
				+ "     \"totalprice\": 111,\r\n"
				+ "     \"depositpaid\": true,\r\n"
				+ "     \"bookingdates\": {\r\n"
				+ "         \"checkin\": \"2018-01-01\",\r\n"
				+ "         \"checkout\": \"2019-01-01\"\r\n"
				+ "     },\r\n"
				+ "     \"additionalneeds\": \"Breakfast\"\r\n"
				+ " }";
		Response response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .accept("text/custom")
		         .when()
		         .body(s)
		         .post();
		response.prettyPrint();
	}
}
