package automation;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Valid {
	@DisplayName("Validate cookies")
	@Test
	void APIresponse() {
		RestAssured.baseURI="https://postman-echo.com/cookies";
		
		Response response = RestAssured
					.given()
			        .relaxedHTTPSValidation()
			        .accept(ContentType.JSON)
			        .cookie("Communication","television")
			        .when()
			        .get(); 
	            
		response.prettyPrint();
		  Map<String, String> allCookies = response.getCookies();
		  for (Map.Entry<String, String> cook : allCookies.entrySet()) {
			    System.out.println(cook.getKey() + " = " + cook.getValue());
			}
		  String com=response.jsonPath().getString("cookies.Communication");
//	        allCookies.forEach((name, value) -> System.out.println(name + " = " + value));
	        System.out.println("communication = " + com);
	        
	       assertEquals(com,"television");
	       
	       assertTrue(allCookies.containsKey("sails.sid"));
	}
}
