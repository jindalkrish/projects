package automation;

import static org.testng.Assert.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Redirect {
	@DisplayName("Follow redirects but not use relaxed HTTPS validation")
	@Test
	void APIresponse() {
		Response response = RestAssured.given()
				.redirects().follow(true)
				.and().relaxedHTTPSValidation() 
		         .when()
		         .get("https://simple-tool-rental-api.glitch.me/status");
		        
		response.prettyPrint();
		assertEquals(response.getStatusCode(),410);
	}
}
