package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Valid {
	@DisplayName("Validating response using Multiple Assertions")
	@Test
	void APIresponse() {
		SoftAssert softAssert = new SoftAssert();
		RestAssured.baseURI="https://restful-booker.herokuapp.com/booking";
		
		String s="{\"firstname\":\"Jim\",\"lastname\":\"Brown\",\"totalprice\":111,\"depositpaid\":true,\"bookingdates\":{\"checkin\":\"2018-01-01\",\"checkout\":\"2019-01-01\"},\"additionalneeds\":\"Breakfast\"}";
		Response response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .contentType(ContentType.JSON)
		         .when()
		         .body(s)
		         .post();
		response.prettyPrint();
		
		softAssert.assertEquals(response.statusCode(), 200, "Status code mismatch");
		softAssert.assertEquals(response.jsonPath().getString("firstname"), "Jim", "Firstname mismatch");
		softAssert.assertEquals(response.jsonPath().getString("lastname"), "Brown", "lastname mismatch");
		softAssert.assertEquals(response.jsonPath().getString("totalprice"), 111, "Total price mismatch");
		softAssert.assertEquals(response.jsonPath().getString("depositpaid"),true,"Deposit status mismatch");
		softAssert.assertEquals(response.jsonPath().getString("additionalneeds"), "Breakfast", "Additional needs mismatch");
	}
}
