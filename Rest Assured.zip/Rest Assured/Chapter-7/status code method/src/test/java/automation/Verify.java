package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class Verify {
	@DisplayName("Verify the response status code with status code method")
	@Test
	void APIresponse() {
		RestAssured.baseURI="https://restful-booker.herokuapp.com/booking";
		
		String s="{\"firstname\":\"Jim\",\"lastname\":\"Brown\",\"totalprice\":111,\"depositpaid\":true,\"bookingdates\":{\"checkin\":\"2018-01-01\",\"checkout\":\"2019-01-01\"},\"additionalneeds\":\"Breakfast\"}";
		 RestAssured.given()
		.relaxedHTTPSValidation() 
         .when()
         .contentType(ContentType.JSON)
         .when()
         .body(s)
         .post()         
         .then()
         .statusCode(200);
}
}
