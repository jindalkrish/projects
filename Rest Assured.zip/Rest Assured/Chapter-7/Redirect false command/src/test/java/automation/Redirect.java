package automation;

import static org.testng.Assert.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Redirect {
	@DisplayName("Utilize the redirect false command")
	@Test
	void APIresponse() {
		Response response = RestAssured.given()
				.redirects().follow(false)
				.relaxedHTTPSValidation() 
		         .when()
		         .get("https://blog.glitch.com/post/changes-are-coming-to-glitch/");
		        
		response.prettyPrint();
		assertEquals(response.getStatusCode(),200);
	}
}
