package automation;

import static org.hamcrest.Matchers.equalTo;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Valid {
	@DisplayName("Validating response using Equality Check")
	@Test
	void APIresponse() {
		RestAssured.baseURI="https://restful-booker.herokuapp.com/booking";
		
		String s="{\"firstname\":\"Jim\",\"lastname\":\"Brown\",\"totalprice\":111,\"depositpaid\":true,\"bookingdates\":{\"checkin\":\"2018-01-01\",\"checkout\":\"2019-01-01\"},\"additionalneeds\":\"Breakfast\"}";
		Response response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .contentType(ContentType.JSON)
		         .when()
		         .body(s)
		         .post();
		response.prettyPrint();
		
		        response.then()
	            .statusCode(200)
	            .body("booking.firstname", equalTo("Jim"))
	            .body("booking.lastname",  equalTo("Brown"))
	            .body("booking.totalprice",  equalTo(111))
	            .body("booking.bookingdates.checkin",  equalTo("2018-01-01"))
	            .body("booking.bookingdates.checkout",  equalTo("2019-01-01"))
	            .body("booking.additionalneeds", equalTo("Breakfast"));
	}
}
