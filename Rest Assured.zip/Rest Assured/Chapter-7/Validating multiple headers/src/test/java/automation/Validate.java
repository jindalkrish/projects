package automation;

import static org.hamcrest.Matchers.equalTo;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Validate {
	@DisplayName("Validating multiple headers")
	@Test
	void APIresponse() {
		RestAssured.baseURI="https://restful-booker.herokuapp.com/booking";
		
		String s="{\"firstname\":\"Jim\",\"lastname\":\"Brown\",\"totalprice\":111,\"depositpaid\":true,\"bookingdates\":{\"checkin\":\"2018-01-01\",\"checkout\":\"2019-01-01\"},\"additionalneeds\":\"Breakfast\"}";
		Response response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .contentType(ContentType.JSON)
		         .when()
		         .body(s)
		         .post();
		response.prettyPrint();
		
		        response.then()
	                .assertThat()
	                .statusCode(200)
	                .headers(
	                        "Content-Type", equalTo("application/json; charset=utf-8"),
	                        "Server", equalTo("Heroku"),
	                        "Content-Length", equalTo("197")
	                    );
	}

}
