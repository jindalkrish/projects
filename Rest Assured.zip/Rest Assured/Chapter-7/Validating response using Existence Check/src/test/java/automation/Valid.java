package automation;

import static org.hamcrest.Matchers.hasKey;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Valid {
	@DisplayName("Validating response using Existence Check")
	@Test
	void APIresponse() {
		RestAssured.baseURI="https://restful-booker.herokuapp.com/booking";
		
		String s="{\"firstname\":\"Jim\",\"lastname\":\"Brown\",\"totalprice\":111,\"depositpaid\":true,\"bookingdates\":{\"checkin\":\"2018-01-01\",\"checkout\":\"2019-01-01\"},\"additionalneeds\":\"Breakfast\"}";
		Response response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .contentType(ContentType.JSON)
		         .when()
		         .body(s)
		         .post();
		response.prettyPrint();
		
		response.then()
        .statusCode(200)
        .body("booking", hasKey("firstname"))
        .body("booking", hasKey("lastname"))
        .body("booking", hasKey("totalprice"))
        .body("booking", hasKey("depositpaid"))
        .body("booking", hasKey("bookingdates"))
        .body("booking", hasKey("additionalneeds"));
	}
}
