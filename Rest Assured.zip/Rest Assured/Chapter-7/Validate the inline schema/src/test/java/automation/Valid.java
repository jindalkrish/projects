package automation;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

import java.io.StringReader;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.SchemaFactory;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Valid {
	@DisplayName("Validate the inline schema")
    @Test
    void validateXmlAgainstXsd() throws Exception {
    	String xsd =  "<xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\">\n" +
    		    "  <xs:element name=\"booking\">\n" +
    		    "    <xs:complexType>\n" +
    		    "      <xs:sequence>\n" +
    		    "        <xs:element name=\"firstname\" type=\"xs:string\"/>\n" +
    		    "        <xs:element name=\"lastname\" type=\"xs:string\"/>\n" +
    		    "        <xs:element name=\"totalprice\" type=\"xs:int\"/>\n" +
    		    "        <xs:element name=\"depositpaid\" type=\"xs:boolean\"/>\n" +
    		    "        <xs:element name=\"bookingdates\">\n" +
    		    "          <xs:complexType>\n" +
    		    "            <xs:sequence>\n" +
    		    "              <xs:element name=\"checkin\" type=\"xs:string\"/>\n" +
    		    "              <xs:element name=\"checkout\" type=\"xs:string\"/>\n" +
    		    "            </xs:sequence>\n" +
    		    "          </xs:complexType>\n" +
    		    "        </xs:element>\n" +
    		    "        <xs:element name=\"additionalneeds\" type=\"xs:string\" minOccurs=\"0\"/>\n" +
    		    "      </xs:sequence>\n" +
    		    "    </xs:complexType>\n" +
    		    "  </xs:element>\n" +
    		    "</xs:schema>";

    	RestAssured.baseURI="https://restful-booker.herokuapp.com/booking/119";
    	Response response=RestAssured
    						.given()
    						.relaxedHTTPSValidation() 
    						.accept("application/xml")
    						.header("Content-Type", "application/xml")
    						.when()
    						.get();
            String xml = response.getBody().asString();
        System.out.println("📦 Response:\n" + xml);

        // Validate XML against XSD
        SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        factory.newSchema(new StreamSource(new StringReader(xsd)))
               .newValidator()
               .validate(new StreamSource(new StringReader(xml)));

        System.out.println("✅ XML is valid against the inline XSD.");
    }
}
