package automation;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Json {
	@DisplayName("Ensure JSON schema data types are not matching")
	@Test
	void APIresponse() {

		Response response = RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .contentType(ContentType.JSON)
		         .when()
		         .get("https://jsonplaceholder.typicode.com/posts/2");
		response.prettyPrint();
		assertEquals(response.getStatusCode(),200);
		Map<String,Object>mp=response.jsonPath().getMap("$");
		assertTrue(mp.get("userId") instanceof String);
		assertTrue(mp.get("id") instanceof String);
		assertTrue(mp.get("title") instanceof String);
		assertTrue(mp.get("body") instanceof String);
	}
}
