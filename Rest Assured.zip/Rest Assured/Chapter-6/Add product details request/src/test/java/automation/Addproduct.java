package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class Addproduct {
	@DisplayName("Success Status code 200 for Add product details request")
	@Test
	void APIresponse() {
		RestAssured.baseURI="https://api.restful-api.dev/objects";
		
		String s="{\"name\":\"Apple MacBook Pro 16\",\"data\":{\"year\":2019,\"price\":1849.99,\"CPU model\":\"Intel Core i9\",\"Hard disk size\":\"1 TB\"}}";
		 RestAssured.given()
		.relaxedHTTPSValidation() 
         .when()
         .contentType(ContentType.JSON)
         .when()
         .body(s)
         .post()         
         .then()
         .statusCode(200);
	}
}
