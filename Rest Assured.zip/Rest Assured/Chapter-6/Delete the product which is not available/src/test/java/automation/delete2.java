package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class delete2 {
	@DisplayName("Delete the product which is not present")
	@Test
	void APIresponse2() {
			
		RestAssured.baseURI="https://api.restful-api.dev/objects";
		
		RestAssured.given()
	        .relaxedHTTPSValidation()
	        .contentType(ContentType.JSON)
	    .when()
	        .delete("/ff8081819782e69e0197e3f6d7ac3f74")
	        .then()
	        .statusCode(404); 
	}
}
