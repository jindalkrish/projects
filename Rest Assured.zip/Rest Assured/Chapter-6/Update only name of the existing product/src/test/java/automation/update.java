package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class update {
	@DisplayName("Update only name of the existing product")
	@Test
	void APIresponse() {
			
		RestAssured.baseURI="https://api.restful-api.dev/objects";
		
		String s="{\"name\":\"Apple MacBook Pro 16 (Updated Name)\"}";
		RestAssured.given()
	        .relaxedHTTPSValidation()
	        .contentType(ContentType.JSON)
	        .body(s)
	    .when()
	        .patch("/ff8081819782e69e0197e3f6d7ac3f74")
	        .then()
	        .statusCode(200);
		 
	   
	}
}
