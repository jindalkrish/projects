package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Addproduct {
	@DisplayName("Print the success response for Add product details request")
	@Test
	void APIresponse() {
		RestAssured.baseURI="https://api.restful-api.dev/objects";
		
		String s="{\"name\":\"Dell I5\",\"data\":{\"year\":2023,\"price\":20000,\"CPU model\":\"Intel Core i9\",\"Hard disk size\":\"2 TB\"}}";
		Response response= RestAssured.given()
				.relaxedHTTPSValidation() 
		         .when()
		         .contentType(ContentType.JSON)
		         .when()
		         .body(s)
		         .post();
		response.prettyPrint();
	}
}
