package automation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class update {
	@DisplayName("print the updated price from response")
	@Test
	void APIresponse() {
		RestAssured.baseURI="https://api.restful-api.dev/objects";
		
		String s="{\"name\":\"Apple MacBook Pro 16\",\"data\":{\"year\":2019,\"price\":4000.99,\"CPU model\":\"Intel Core i9\",\"Hard disk size\":\"1 TB\",\"color\":\"silver\"}}";
		Response response= RestAssured
	    .given()
	        .relaxedHTTPSValidation()
	        .contentType(ContentType.JSON)
	        .body(s)
	    .when()
	        .put("/ff8081819782e69e0197e3f6d7ac3f74");
		 float updatedPrice = response.jsonPath().getFloat("data.price");
	        System.out.println("Updated Price: $" + updatedPrice);
	   
	}
}
