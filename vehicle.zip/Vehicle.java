interface Vehicle {
    public void start();
    public void stop();
    public void accelerate();
    public void brake();
}