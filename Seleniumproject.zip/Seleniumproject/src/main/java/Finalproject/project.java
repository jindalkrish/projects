package Finalproject;

import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;;
public class project {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		driver.get("www.xyz.com");
		driver.manage().window().maximize();
		driver.findElement(By.id("name")).sendKeys("krish");
		driver.findElement(By.id("pass")).sendKeys("password");
		driver.findElement(By.id("submit")).click();
		List<WebElement>l=driver.findElements(By.className("drop-down"));
		if(l.size()>0) {
			System.out.println("drop-down is present");
		}
		driver.quit();
	}

}
