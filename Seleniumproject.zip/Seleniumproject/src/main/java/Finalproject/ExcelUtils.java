package Finalproject;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ExcelUtils {
	WebDriver driver;
	public ExcelUtils(WebDriver driver) {
		this.driver=driver;
	}
	//Enter the List of Packages in Excel
			public void Excel(List<String>packs) throws Exception{
				// TODO Auto-generated method stub
				XSSFWorkbook workbook = new XSSFWorkbook();
		        XSSFSheet sheet = workbook.createSheet("Test Data");

		        for(int i=0;i<packs.size();i++) {
		        XSSFRow row = sheet.createRow(i);   
		        row.createCell(0).setCellValue(packs.get(i));
		        try (FileOutputStream fileOut = new FileOutputStream("Data.xlsx")) {
		            workbook.write(fileOut);
		        }
		        catch (Exception e) {
		            e.printStackTrace();
		        }
		        }
		        System.out.println("Data written to Excel file successfully!");

		        // Close the workbook
		        workbook.close();
			}
}
