package Finalproject;

import java.io.File;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Offers{
	WebDriver driver;
	
	//initiate driver
	public Offers(WebDriver driver) {
		this.driver=driver;
	}
	
	
	//Navigate to the Offers page
	public void viewoffers() {
		
		List<WebElement> elements = driver.findElements(By.xpath("//*[@id=\"__next\"]/div/div[1]/div[1]/div[2]/div/section[2]/span/img"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", elements.get(0));
         driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div[1]/div/div[2]/div[2]/div")).click();

         String current=driver.getWindowHandle();
         Set<String>handles=driver.getWindowHandles();
         for (String windowHandle : handles) {
             if (!windowHandle.equals(current)) {
                 // Switch to the new window
                 driver.switchTo().window(windowHandle);
                 break;
             }
         }
	}
	
	//Title Validation
	public void validtitle() {
		 String pageTitle=driver.getTitle();
         String title="Domestic Flights Offers | Deals on Domestic Flight Booking | Yatra.com";
         Assert.assertEquals(pageTitle, title);
         if(pageTitle.equals(title)) {
         	System.out.println("Page Title is Valid");
         }
         else {
         	System.out.println("Page Title is not Valid");
         }
	}
	
	//Banner Text Validation
	public void validbanner() {
         String b="Great Offers & Amazing Deals";
         WebElement banner=driver.findElement(By.tagName("h2"));
         Assert.assertEquals(b,banner.getText());
         if(b.equals(banner.getText())) {
         	System.out.println("Banner Text is Valid");
         }
         else {
         	if(b.equals(banner.getText())) {
             	System.out.println("Banner Text is Valid");
             }
         }
         System.out.println();
	}
	
	
	//Take Screenshot
		public void screen() throws Exception {
         File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
         File destination = new File("screenshot1.png");
         FileHandler.copy(screenshot, destination);
         System.out.println("Screenshot saved at: " + destination.getAbsolutePath());
         System.out.println();
		}
         
		//Navigate to Holiday Offers
         public void navigatetoholiday() throws Exception{
         driver.findElement(By.xpath("//*[@id=\"offer-box-shadow\"]/li[4]")).click();
         Thread.sleep(3000);
         }
        
	}
