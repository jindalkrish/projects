package Finalproject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Optional;
import org.testng.annotations.*;
import org.openqa.selenium.edge.EdgeDriver;

import java.io.IOException;
import java.util.*;

public class Home {
	
	 WebDriver driver;
	 String browserName;
	 Offers offer;
	 Holidays holiday;
	 ExcelUtils excel;
	@Parameters("browser")
    @BeforeClass
    public void setup(@Optional("chrome")String browser) {
		this.browserName=browser;
		System.out.println("Launching"+browserName+"Browser.....");
		if (browser.equals("chrome")) {
	        driver = new ChromeDriver();
	    } else if (browser.equals("edge")) {
	        driver = new EdgeDriver();
	    } else {
	        throw new IllegalArgumentException("Invalid browser type: " + browser);
	    }
        
        //Open Yatra Website
		driver.get("https://www.yatra.com/");
		
		//maximize the window
        driver.manage().window().maximize();
		
		//Offers class object
		offer=new Offers(driver);
		
		//Holidays class object
		holiday=new Holidays(driver);
		
		//excel class object
		excel=new ExcelUtils(driver);
    }
	
	
	//All the Methods from all classes call in this Method
	@Test
	public void testprogram(){
		// TODO Auto-generated method stub
		   try {
			   
			   offer.viewoffers();
			   offer.validtitle();
			   offer.validbanner();
			   offer.screen();
			   offer.navigatetoholiday();
			   List<String>packs=holiday.holidayslist();
			   holiday.display();
			   excel.Excel(packs);
			   
	        }
	        catch (Exception e) {
	            e.printStackTrace();
	        } 
	}
	
		//Quit the driver
		   @AfterClass
		   public void tearDown() {
		        driver.quit();
		    }
		   

}
